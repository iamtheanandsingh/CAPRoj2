import os
import re

def extract_lines(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
        filtered_lines = [line.strip() for line in lines if any(keyword in line for keyword in keywords)]
    return filtered_lines

def extract_numerical_values(line):
    # Using regular expression to extract numerical values from the line
    return re.findall(r'\b\d+\.*\d*\b', line)

# def calculate_cpi(dcache_misses, icache_misses, l2_misses):
#     return ((int(dcache_misses) * 6 + int(icache_misses) * 6 + int(l2_misses) * 50) / 100000000) + 1


def calculate_cpi(dcache_misses, icache_misses, l2_misses):
    # Calculate CPI using the provided formula
    return ((int(dcache_misses) * 6 + int(icache_misses) * 6 + int(l2_misses) * 50) / 100000000) + 1

cpiVsValueFile={}
cpiVsValue={}
cpiVsFile={}


def process_folder(folder_path):
    outer_hashmap = {keyword: {} for keyword in keywords}
    # cpiVsValueFile={}
    fileMissRatesForCPI = {}
    for filename in os.listdir(folder_path):
        # fileMissRatesForCPI = {}
        inner_hashmap = {}
        if filename.endswith(".txt"):
            file_path = os.path.join(folder_path, filename)
            extracted_lines = extract_lines(file_path)
            
            key = re.search(r'-(\d+)\.txt', filename).group(1)
            for keyword in keywords:
                keyword_lines = [line for line in extracted_lines if keyword in line]
                if keyword_lines:
                    # inner_hashmap = {}
                    for line in keyword_lines:
                        numerical_values = extract_numerical_values(line)
                        if numerical_values:
                            # Using the numeric value between - and .txt of file name as the key
                            # key = re.search(r'-(\d+)\.txt', filename).group(1)
                            inner_hashmap[key] = numerical_values[0]  # Use the first value in the list
                            # inner_hashmap[key] = {
                            #     'value': numerical_values[0],
                            # }

                            if keyword in cpiKeywords:
                                fileMissRatesForCPI[keyword] = numerical_values[0]
                                # inner_hashmap[key]['cpi'] = calculate_cpi(*numerical_values)
                    
                    if inner_hashmap:
                        outer_hashmap[keyword][key] = inner_hashmap[key]
                    
                    # print(fileMissRatesForCPI)
        
            print(fileMissRatesForCPI)
            if(inner_hashmap):
                config_string="L1I_SIZE=32-L1D_SIZE=32-L2_SIZE=32-CACHELINE_SIZE=64-L1D_ASSOC=4-L1I_ASSOC=4-L2_ASSOC=4"
                config_string = config_string.replace("L2_ASSOC=4", "L2_ASSOC=" + key)
                cpi = calculate_cpi(fileMissRatesForCPI['system.cpu.dcache.overall_misses::total'], fileMissRatesForCPI['system.cpu.dcache.overall_misses::total'], fileMissRatesForCPI['system.cpu.dcache.overall_misses::total'])
                # inner_hashmap[key]['cpi'] = cpi
                # cpiVsValueFile['cpi-' + key ] = cpi 
                cpiVsValue[key] = cpi 
                # print('key : ', key)
                # print(key[6:])
                cpiVsValueFile[filename[6:-4]] = cpi 
                cpiVsFile[config_string] = cpi



                

            # print("CPI of "+ filename + ": ", inner_hashmap[key]['cpi'])
            # print("CPI of "+ filename + ": ", cpiVsValueFile['cpi-'+key])
            print("CPI of "+ filename[6:-4] + ": ", cpiVsValueFile[filename[6:-4]])


    print(max(cpiVsValueFile.items(), key=lambda x: x[1]))
    print(cpiVsValueFile)
    return outer_hashmap

# List of keywords to search for
keywords = [
    "system.cpu.dcache.overall_misses::total",
    "system.cpu.icache.overall_misses::total",
    "system.l2.overall_misses::total",
    "system.cpu.dcache.overall_miss_rate::total",
    "system.cpu.icache.overall_miss_rate::total",
    "system.l2.overall_miss_rate::total"
]

# List of keywords to calculate CPI for
cpiKeywords = [
    "system.cpu.dcache.overall_misses::total",
    "system.cpu.icache.overall_misses::total",
    "system.l2.overall_misses::total",
]

# Folder path containing the .txt files
folder_path = "/home/011/a/ax/axs230094/458sjeng data/L2 Associativity"

result_hashmap = process_folder(folder_path)

# Print the resulting hashmap
# for keyword, inner_hashmap in result_hashmap.items():
#     print(f"Keyword: {keyword}")
#     for key, value in inner_hashmap.items():
#         print(f"  File Key: {key}")
#         print(f"  Value: {value}")
#         if 'cpi' in value:
#             print(f"  CPI: {value['cpi']}")

print(cpiVsValueFile)
print(cpiVsValue)
print(cpiVsFile)
# print(result_hashmap)