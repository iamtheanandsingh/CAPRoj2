#!/bin/bash

# Set gem5 directory
export GEM5_DIR=/usr/local/gem5

# Set benchmark executable and input
export BENCHMARK=./src/benchmark
export ARGUMENT=./data/test.txt

# Set output directory
BASE_OUTPUT_DIR=~/m5out

# Constants
L1I_SIZE=32
L1D_SIZE=32
L2_SIZE=32
CACHELINE_SIZE=64
L1D_ASSOC=4
L1I_ASSOC=4
L2_ASSOC=4

# Global hashmap for collecting costs with config name as the key
declare -A ConfigCostHashMap

# Global hashmap for collecting costs with txt file name (without extension) as the key
declare -A TxtFileNameCostHashMap


# Define variable input range
L1D_SIZES=(1 2 4 8 16 32 64 128)
L1I_SIZES=(1 2 4 8 16 32 64 128)
L2_SIZES=(1 2 4 8 16 32 64 128)
CACHELINE_SIZES=(8 16 32 64 128 256 512)
L1D_ASSOCS=(1 2 4 8)
L1I_ASSOCS=(1 2 4 8)
L2_ASSOCS=(1 2 4 8)


# Create a folder to collect generated files
COLLECTION_FOLDER=~/m5out/collected_files
mkdir -p "$COLLECTION_FOLDER"

# Global variable for simulation number
GlobalSimulationNumber=0

# Global timer for the entire program
TotalProgramTimer=0

# Function to increment and print the simulation number
increment_and_print_simulation_number() {
    ((GlobalSimulationNumber++))
    echo "Simulation Number: $GlobalSimulationNumber"
}

# Function to print start time with variable name
print_start_time() {
    echo "Start Time of $1: $(date)"
    increment_and_print_simulation_number
}

# Function to print end time and time taken with variable name
print_end_time() {
    echo "End Time of $1: $(date)"
    local duration=$SECONDS
    echo "Time Taken by $1: $(($duration / 60)) minutes and $(($duration % 60)) seconds."
}

# Function to calculate cache cost
calculate_cost() {
    local l1d_size=$1
    local l1i_size=$2
    local l2_size=$3
    local cacheline_size=$4
    local l1d_assoc=$5
    local l1i_assoc=$6
    local l2_assoc=$7

    # Define base cost for different cache levels
    l1d_base_cost=2  # Arbitrary cost unit for L1D cache
    l1i_base_cost=2  # Arbitrary cost unit for L1I cache
    l2_base_cost=1   # Arbitrary cost unit for L2 cache

    # Size-dependent cost factors
    size_cost_factor=$((l1d_size + l1i_size + l2_size))

    # Associativity-dependent cost factors
    assoc_cost_factor=$((l1d_assoc + l1i_assoc + l2_assoc))

    # Cacheline size-dependent cost factors
    cacheline_cost_factor=$cacheline_size

    # Calculate total cost
    total_cost=$((l1d_base_cost * size_cost_factor * assoc_cost_factor * cacheline_cost_factor +
                   l1i_base_cost * size_cost_factor * assoc_cost_factor * cacheline_cost_factor +
                   l2_base_cost * size_cost_factor * assoc_cost_factor * cacheline_cost_factor))

    echo "Total Cost: $total_cost"
}


# Function to run gem5 simulation
run_gem5_simulation() {
    local config_name=$1
    local config_flags=$2
    local param3=$3
    local param4=$4
    local param5=$5
    local param6=$6
    local param7=$7
    local param8=$8
    local param9=$9


    # Create output directory
    local output_dir_base="$BASE_OUTPUT_DIR/$config_name"
    mkdir -p "$output_dir_base"

    # Print start time
    print_start_time "Simulation $config_name"

    # Start the timer for the simulation
    local SimulationTimer=0
    SECONDS=0

    # Build gem5 command
    local gem5_command="$GEM5_DIR/build/X86/gem5.opt -d $output_dir_base $GEM5_DIR/configs/example/se.py"
    gem5_command+=" -c $BENCHMARK -o $ARGUMENT -I 100000000 --cpu-type=atomic --caches --l2cache"
    gem5_command+=" $config_flags &> $output_dir_base/output.txt"

    # Print and execute gem5 command
    echo "Running command for $config_name:"
    echo "$gem5_command"
    eval "$gem5_command"

    # Stop the timer for the simulation
    SimulationTimer=$SECONDS

    # Print end time and time taken for the simulation
    print_end_time "Simulation $config_name" "$SimulationTimer"

    # Copy stats.txt to collection folder
    local stats_file="$output_dir_base/stats.txt"
    cp "$stats_file" "$COLLECTION_FOLDER/stats_${config_name}.txt"

    # Get the exact name of the txt file without extension
    local txt_file_name=$(basename "$stats_file" .txt)


    # Before the calculate_cost call, add debug prints
    echo "Debug: l1d_size=$param3, l1i_size=$param4, l2_size=$param5 , cacheline_size=$param9, l1d_assoc=$param6, l1i_assoc=$param7, l2_assoc=$param8"  # Add all relevant variables

    # Print cost for the simulation
    # Calculate cost using the calculate_cost function
    local cost=$(calculate_cost "${param3}" "${param4}" "${param5}" "${param9}" "${param6}" "${param7}" "${param8}")

    echo "Debug: cost calculated=$cost"

    ConfigCostHashMap["$config_name"]=$cost
    TxtFileNameCostHashMap["$txt_file_name"]=$cost

    echo "Debug: Cost added to hashmaps"
    # Accumulate the time taken for the simulation to the total program timer
    ((TotalProgramTimer += SimulationTimer))
}


# Function to calculate cost for the simulation
calculate_cost_for_simulation() {
    local config_name=$1

    # Extract configuration values from config_name
    IFS='-' read -ra config_values <<< "$config_name"

    # Call calculate_cost function with extracted values
    calculate_cost "${config_values[@]}"
}


# Function to print program start time
print_program_start_time() {
    echo "Start Time of Entire Program: $(date)"
}

# Function to print program end time and time taken
print_program_end_time() {
    echo "End Time of Entire Program: $(date)"
    echo "Total Time Taken by Entire Program: $(($TotalProgramTimer / 60)) minutes and $(($TotalProgramTimer % 60)) seconds."
    echo "Total Number of Simulations: $GlobalSimulationNumber"


    # Print cost hashmaps
    echo "Config Name - Cost HashMap:"
    for key in "${!ConfigCostHashMap[@]}"; do
        echo "  $key: ${ConfigCostHashMap[$key]}"
    done

    echo "Txt File Name - Cost HashMap:"
    for key in "${!TxtFileNameCostHashMap[@]}"; do
        echo "  $key: ${TxtFileNameCostHashMap[$key]}"
    done
}

# Print program start time
print_program_start_time

# Loop through the variable L1D Size
for l1d_size in "${L1D_SIZES[@]}"; do
    run_gem5_simulation "l1d_size-$l1d_size" "--l1d_size=${l1d_size}kB --l1i_size=${L1I_SIZE}kB --l2_size=${L2_SIZE}MB --l1d_assoc=${L1D_ASSOC} --l1i_assoc=${L1I_ASSOC} --l2_assoc=${L2_ASSOC} --cacheline_size=${CACHELINE_SIZE}" ${l1d_size} ${L1I_SIZE} ${L2_SIZE} ${L1D_ASSOC} ${L1I_ASSOC} ${L2_ASSOC} ${CACHELINE_SIZE}
done

# Loop through the variable L2 Assoc
for l2_assoc in "${L2_ASSOCS[@]}"; do
    run_gem5_simulation "l2_assoc-$l2_assoc" "--l1d_size=${L1D_SIZE}kB --l1i_size=${L1I_SIZE}kB --l2_size=${L2_SIZE}MB --l1d_assoc=${L1D_ASSOC} --l1i_assoc=${L1I_ASSOC} --l2_assoc=${l2_assoc} --cacheline_size=${CACHELINE_SIZE}" ${L1D_SIZE} ${L1I_SIZE} ${L2_SIZE} ${L1D_ASSOC} ${L1I_ASSOC} ${l2_assoc} ${CACHELINE_SIZE}
done

# Loop through the variable L1I Size
for l1i_size in "${L1I_SIZES[@]}"; do
    run_gem5_simulation "l1i_size-$l1i_size" "--l1d_size=${L1D_SIZE}kB --l1i_size=${l1i_size}kB --l2_size=${L2_SIZE}MB --l1d_assoc=${L1D_ASSOC} --l1i_assoc=${L1I_ASSOC} --l2_assoc=${L2_ASSOC} --cacheline_size=${CACHELINE_SIZE}" ${L1D_SIZE} ${l1i_size} ${L2_SIZE} ${L1D_ASSOC} ${L1I_ASSOC} ${L2_ASSOC} ${CACHELINE_SIZE}
done

# Loop through the variable L2 Size
for l2_size in "${L2_SIZES[@]}"; do
    run_gem5_simulation "l2_size-$l2_size" "--l1d_size=${L1D_SIZE}kB --l1i_size=${L1I_SIZE}kB --l2_size=${l2_size}MB --l1d_assoc=${L1D_ASSOC} --l1i_assoc=${L1I_ASSOC} --l2_assoc=${L2_ASSOC} --cacheline_size=${CACHELINE_SIZE}" ${L1D_SIZE} ${L1I_SIZE} ${l2_size} ${L1D_ASSOC} ${L1I_ASSOC} ${L2_ASSOC} ${CACHELINE_SIZE}
done

# Loop through the variable L1I Assoc
for l1i_assoc in "${L1I_ASSOCS[@]}"; do
    run_gem5_simulation "l1i_assoc-$l1i_assoc" "--l1d_size=${L1D_SIZE}kB --l1i_size=${L1I_SIZE}kB --l2_size=${L2_SIZE}MB --l1d_assoc=${L1D_ASSOC} --l1i_assoc=${l1i_assoc} --l2_assoc=${L2_ASSOC} --cacheline_size=${CACHELINE_SIZE}" ${L1D_SIZE} ${L1I_SIZE} ${L2_SIZE} ${L1D_ASSOC} ${l1i_assoc} ${L2_ASSOC} ${CACHELINE_SIZE}
done

# Loop through the variable L1D Assoc
for l1d_assoc in "${L1D_ASSOCS[@]}"; do
    run_gem5_simulation "l1d_assoc-$l1d_assoc" "--l1d_size=${L1D_SIZE}kB --l1i_size=${L1I_SIZE}kB --l2_size=${L2_SIZE}MB --l1d_assoc=${l1d_assoc} --l1i_assoc=${L1I_ASSOC} --l2_assoc=${L2_ASSOC} --cacheline_size=${CACHELINE_SIZE}" ${L1D_SIZE} ${L1I_SIZE} ${L2_SIZE} ${l1d_assoc} ${L1I_ASSOC} ${L2_ASSOC} ${CACHELINE_SIZE}
done

# Loop through the variable CacheLine Size
for cacheline_size in "${CACHELINE_SIZES[@]}"; do
    run_gem5_simulation "cacheline_size-$cacheline_size" "--l1d_size=${L1D_SIZE}kB --l1i_size=${L1I_SIZE}kB --l2_size=${L2_SIZE}MB --l1d_assoc=${L1D_ASSOC} --l1i_assoc=${L1I_ASSOC} --l2_assoc=${L2_ASSOC} --cacheline_size=${cacheline_size}" ${L1D_SIZE} ${L1I_SIZE} ${L2_SIZE} ${L1D_ASSOC} ${L1I_ASSOC} ${L2_ASSOC} ${cacheline_size}
done

# Print program end time and time taken
print_program_end_time
